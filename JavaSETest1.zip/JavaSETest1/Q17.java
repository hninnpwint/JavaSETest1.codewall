package JavaSETest1;

public class Q17 {
    public static void main(String[] args) {
        int i = 5;
        int j = 5;

        for (int a = 0; a< i; a++) {
            for (int b = 0; b < j; b++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
    }

