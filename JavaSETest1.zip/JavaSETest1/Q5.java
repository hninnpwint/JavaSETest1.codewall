package JavaSETest1;

public class Q5 {
    public static void main(String[] args) {
        int num1= 3;
        int num2 = 4;


        System.out.println("The original numbers are: "+num1+"and"+num2);

        int switchnums= num1;
        num1 = num2;
        num2 = switchnums;

        System.out.println("Switched numbers are :"+num1+"  and "+num2);

    }
}


