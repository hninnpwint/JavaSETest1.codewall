package JavaSETest1;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class Q11 {
    public static void main(String[] args) {
        int numbers[]={2,4,6,8,10};
        for(int i=0;i<numbers.length;i++){
            System.out.println("our numbers in array are: "+numbers[i]);

        }
        Scanner scanner=new Scanner(System.in);
        System.out.println("PLease enter the one U wants to delete!");
        int delnum= scanner.nextInt();

        //not complet my program

            System.out.println("The answer is ");
        }

    }

