package JavaSETest1;

import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Please enter the first number:");
        int num1= scanner.nextInt();
        System.out.println("Please enter the second number:");
        int num2=scanner.nextInt();

        int numbers []={num1,num2};
        numbers[0]=num2;
        numbers[1]=num1;

        System.out.println("Your numbers are"+numbers[0]+"and"+numbers[1]);
    }
}
