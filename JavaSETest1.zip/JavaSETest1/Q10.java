package JavaSETest1;

import java.util.Scanner;

public class Q10 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);


        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        int[] userarray = new int[size];

        System.out.println("Enter the numbers included in the array:");

        for (int i = 0; i < size; i++) {
            System.out.print("numbers : " + (i + 1) + ": ");
            userarray[i] = scanner.nextInt();
        }
        for (int i = 0; i < size - 1; i++) {
            for (int j = i + 1; j < size; j++) {
                if (userarray[j] > userarray[i]) {
                    int temp = userarray[i];
                    userarray[i] = userarray[j];
                    userarray[j] = temp;
                }
            }
        }

        System.out.println("The answer is:");
        for (int num : userarray) {
            System.out.print(num + " ");
        }
    }

    }

