package JavaSETest1;

public class Q6 {
    public static void main(String[] args) {
        String st1= "I love";
        String st2 = "You";


        System.out.println("The original strings are : "+st1+" and "+st2);

        String switchstrings= st1;
        st1 = st2;
        st2 = switchstrings;

        System.out.println("Switched strings are :"+st1+" and "+st2);

    }
    }

