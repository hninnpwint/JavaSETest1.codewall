package JavaSETest1;

public class Q22 {
    public static void main(String[] args) {
        int[] numbers= {1, 5, 3, 7, 2, 14};
        for (int i = numbers.length - 1; i >= 0; i--) {
            System.out.print(numbers[i] + " ");
        }
        System.out.println();
    }


    }

