package JavaSETest1;

public class Q8 {
    public static void main(String[] args) {
        //   1 2 3 4 5
        //   5 4 3 2 1
        // 7 8 9 1 5 7 7
        int numbers[][] = {{1, 2, 3, 4, 5}, {5, 4, 3, 2, 1}, {7, 8, 9, 1, 5, 7, 7}};
        for (int i = 0; i < numbers.length; i++) {
            // System.out.println(numbers[i]);
            for (int num : numbers[i]) {
                System.out.print(num);
            }
            System.out.println();

        }
    }

}
