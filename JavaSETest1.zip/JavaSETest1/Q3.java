package JavaSETest1;

import java.util.Scanner;

public class Q3 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Please write the number1:");
        int num1= scanner.nextInt();
        System.out.println("Please write the num2:");
        int num2= scanner.nextInt();
        System.out.println("Please write the num3:");
        int num3= scanner.nextInt();
        System.out.println("Please write the num4:");
        int num4= scanner.nextInt();

        int numbers[]={num1,num2,num3,num4};


        int largestNumber = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > largestNumber) {
                largestNumber = numbers[i];
            }
        }
        System.out.println("The answer is"+largestNumber);

    }
        }


