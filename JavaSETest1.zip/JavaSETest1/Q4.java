package JavaSETest1;

public class Q4 {
    public static void main(String[] args) {

    }
}
