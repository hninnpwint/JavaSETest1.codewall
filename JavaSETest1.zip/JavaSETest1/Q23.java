package JavaSETest1;

public class Q23 {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5, 6};

        System.out.println("Numbers in the array:");

        for (int num : numbers) {
            System.out.println("The answers is: "+num);
        }
    }
}
