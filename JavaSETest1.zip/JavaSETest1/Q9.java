package JavaSETest1;

public class Q9 {
    public static void main(String[] args) {
        int numbers[]={11,45,34,67};
        for(int i=0;i<numbers.length;i++){
            System.out.println(numbers[i]+"Its particular index is "+i);
        }
    }
}
