package JavaSETest1;

import java.util.Scanner;

public class Q15 {

    public static void main(String[] args) {

                Scanner scanner=new Scanner(System.in);

                System.out.print("Enter the size of the array: ");
                int size = scanner.nextInt();

                int[] array = new int[size];

                System.out.println("Enter the numbers of the array:");

                for (int i = 0; i < size; i++) {
                    System.out.print("number " + (i + 1) + ": ");
                    array[i] = scanner.nextInt();
                }

                int even = 0;
                int odd = 0;

                for (int num : array) {
                    if (num % 2 == 0) {
                        even++;
                    } else {
                        odd++;
                    }
                }

                System.out.println("Total odd numbers: " + odd);
                System.out.println("Total even numbers: " + even);
            }
        }



