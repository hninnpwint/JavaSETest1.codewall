package JavaSETest1;

public class Q20 {
    public static void main(String[] args) {
        int num = 20;



        for (int number = 2; number <=num; number++) {
            boolean primenum = true;

            for (int i = 2; i < number; i++) {
                if (number % i == 0) {
                    primenum= false;
                    break;
                }
            }

            if (primenum) {
                System.out.print(number + " ");
            }
        }
    }
}
