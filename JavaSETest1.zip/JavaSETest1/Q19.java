package JavaSETest1;

public class Q19 {
    public static void main(String[] args) {

                int lines = 5;

                for (int i = 1; i <= lines; i++) {
                    for (int j = 1; j < i; j++) {
                        System.out.print("   ");
                    }
                    for (int k = i; k <= lines; k++) {
                        System.out.print(k + " ");
                    }
                    System.out.println();
                }
            }
        }


