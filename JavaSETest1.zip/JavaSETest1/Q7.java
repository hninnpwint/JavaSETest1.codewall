package JavaSETest1;

import java.util.Scanner;

public class Q7 {
    public static void main(String[] args) {
        //{1 2 3 4 5 6 7 } =>{2 4 6 8 10 12 14 }


    }
}

